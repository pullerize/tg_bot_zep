import logging
from telegram import Update
from telegram.ext import (
    Application, 
    CommandHandler, 
    MessageHandler, 
    ConversationHandler,
    filters, 
    ContextTypes
)
from config import BOT_TOKEN
from states import NAME, CITY, MODEL, PHONE
from handlers_new import (
    start,
    language_selected,
    change_language,
    start_application,
    get_name,
    get_city,
    get_model,
    get_phone,
    cancel,
    contacts
)

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.error("Exception while handling an update:", exc_info=context.error)


def main() -> None:
    application = Application.builder().token(BOT_TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[
            MessageHandler(
                filters.Regex("^(📝 Оставить заявку|📝 Ariza qoldirish)$"), 
                start_application
            )
        ],
        states={
            NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_name)],
            CITY: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_city)],
            MODEL: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_model)],
            PHONE: [
                MessageHandler(filters.CONTACT, get_phone),
                MessageHandler(filters.TEXT & ~filters.COMMAND, get_phone)
            ],
        },
        fallbacks=[
            MessageHandler(filters.Regex("^(❌ Отмена|❌ Bekor qilish)$"), cancel),
            CommandHandler("cancel", cancel)
        ],
    )

    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(
        filters.Regex("^(🇷🇺 Русский|🇺🇿 O'zbekcha)$"), 
        language_selected
    ))
    application.add_handler(conv_handler)
    application.add_handler(MessageHandler(
        filters.Regex("^(📞 Контакты|📞 Kontaktlar)$"), 
        contacts
    ))
    application.add_handler(MessageHandler(
        filters.Regex("^(🌐 Сменить язык|🌐 Tilni o'zgartirish)$"), 
        change_language
    ))

    application.add_error_handler(error_handler)

    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == '__main__':
    main()