TEXTS = {
    'ru': {
        # Язык
        'language_choice': '🌐 Выберите язык / Tilni tanlang:',
        
        # Главное меню
        'welcome': '👋 Добро пожаловать!\n\nЭтот бот поможет вам быстро и удобно оформить заявку.\nИспользуйте меню ниже для продолжения.',
        'main_menu_application': '📝 Оставить заявку',
        'main_menu_contacts': '📞 Контакты',
        'main_menu_language': '🌐 Сменить язык',
        
        # Процесс заявки
        'start_application': '📝 Начинаем оформление заявки.\n\nПожалуйста, введите ваше имя и фамилию:',
        'name_too_short': '❌ Имя слишком короткое. Пожалуйста, введите полное имя и фамилию:',
        'ask_city': '✅ Отлично, {}!\n\nИз какого вы города?',
        'city_too_short': '❌ Название города слишком короткое. Пожалуйста, введите корректное название:',
        'ask_model': '🚜 Какая модель техники вас интересует?\n\nПожалуйста, укажите модель и марку:',
        'model_too_short': '❌ Описание модели слишком короткое. Пожалуйста, укажите модель техники:',
        'ask_phone': '📱 Отлично! Теперь нам нужен ваш номер телефона для связи.\n\nВведите оставшиеся 9 цифр после +998:\nФормат: XX XXX XX XX\n\nИли отправьте контакт кнопкой ниже:',
        'phone_invalid': '❌ Неверный формат! Введите ровно 9 цифр после +998\n\nПример: 90 123 45 67\nИли просто: 901234567',
        
        # Подтверждение заявки
        'application_success': '✅ <b>Заявка успешно принята!</b>\n\nВаш номер заявки: <b>{}</b>\n\n📋 <b>Ваши данные:</b>\n• Имя: {}\n• Город: {}\n• Модель: {}\n• Телефон: {}\n\n📞 Наш менеджер свяжется с вами в ближайшее время!',
        
        # Кнопки
        'cancel': '❌ Отмена',
        'send_contact': '📱 Отправить номер телефона',
        'application_cancelled': '❌ Оформление заявки отменено.',
        
        # Контакты
        'contacts': '📞 *Контакты*\n\n☎️ Телефон: +998 88 501 99 33\n📧 Email: zub-centralasia@zeppelin.com\n🌐 Сайт: https://www.zeppelin.uz/\n📍 Адрес: 100160, г. Ташкент, Сергелийский район, Кольцевая автомобильная дорога, Ханабад, Кумарик МСГ, д. 7 Б',
        
        # Для канала
        'channel_header': '🎯 НОВАЯ ЗАЯВКА',
        'channel_client': 'Клиент',
        'channel_city': 'Город',
        'channel_interested': 'Интересует',
        'channel_phone': 'Телефон',
    },
    'uz': {
        # Til
        'language_choice': '🌐 Выберите язык / Tilni tanlang:',
        
        # Asosiy menyu
        'welcome': "👋 Xush kelibsiz!\n\nBu bot sizga tez va qulay tarzda ariza berishga yordam beradi.\nDavom etish uchun quyidagi menyudan foydalaning.",
        'main_menu_application': "📝 Ariza qoldirish",
        'main_menu_contacts': "📞 Kontaktlar",
        'main_menu_language': '🌐 Tilni o\'zgartirish',
        
        # Ariza jarayoni
        'start_application': "📝 Ariza rasmiylashtirish boshlanmoqda.\n\nIltimos, ismingiz va familiyangizni kiriting:",
        'name_too_short': "❌ Ism juda qisqa. Iltimos, to'liq ism va familiyangizni kiriting:",
        'ask_city': "✅ Zo'r, {}!\n\nQaysi shahardan siz?",
        'city_too_short': "❌ Shahar nomi juda qisqa. Iltimos, to'g'ri nomni kiriting:",
        'ask_model': "🚜 Qaysi texnika modeli sizni qiziqtiradi?\n\nIltimos, model va markasini ko'rsating:",
        'model_too_short': "❌ Model tavsifi juda qisqa. Iltimos, texnika modelini ko'rsating:",
        'ask_phone': "📱 Ajoyib! Endi bog'lanish uchun telefon raqamingiz kerak.\n\n+998 dan keyingi 9 ta raqamni kiriting:\nFormat: XX XXX XX XX\n\nYoki kontaktni tugma orqali yuboring:",
        'phone_invalid': "❌ Noto'g'ri format! +998 dan keyin aynan 9 ta raqam kiriting\n\nMisol: 90 123 45 67\nYoki oddiy: 901234567",
        
        # Ariza tasdiqi
        'application_success': "✅ <b>Ariza muvaffaqiyatli qabul qilindi!</b>\n\nSizning ariza raqamingiz: <b>{}</b>\n\n📋 <b>Sizning ma'lumotlaringiz:</b>\n• Ism: {}\n• Shahar: {}\n• Model: {}\n• Telefon: {}\n\n📞 Bizning menejerimiz tez orada siz bilan bog'lanadi!",
        
        # Tugmalar
        'cancel': "❌ Bekor qilish",
        'send_contact': "📱 Telefon raqamini yuborish",
        'application_cancelled': "❌ Ariza rasmiylashtiruvi bekor qilindi.",
        
        # Kontaktlar
        'contacts': "📞 *Kontaktlar*\n\n☎️ Telefon: +998 88 501 99 33\n📧 Email: zub-centralasia@zeppelin.com\n🌐 Sayt: https://www.zeppelin.uz/\n📍 Manzil: 100160, Toshkent sh., Sergeli tumani, Halqa avtomobil yo'li, Xonobod, Qumariq MFY, 7 B",
        
        # Kanal uchun
        'channel_header': "🎯 YANGI ARIZA",
        'channel_client': "Mijoz",
        'channel_city': "Shahar",
        'channel_interested': "Qiziqtiradi",
        'channel_phone': "Telefon",
    }
}

def get_text(lang, key):
    return TEXTS.get(lang, TEXTS['ru']).get(key, TEXTS['ru'].get(key, key))